"""ts-forecast-pipeline
"""

__version__ = "0.1"
